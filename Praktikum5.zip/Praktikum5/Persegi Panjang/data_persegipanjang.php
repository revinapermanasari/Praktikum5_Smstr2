<?php
// Import class PersegiPanjang
require_once 'class_persegipanjang.php';

// Membuat objek PersegiPanjang dengan panjang 5 dan lebar 3
$persegiPanjang = new PersegiPanjang(5, 3);

// Menghitung luas dan keliling persegi panjang
$luas = $persegiPanjang->luas();
$keliling = $persegiPanjang->keliling();

// Menampilkan hasil
echo "Luas persegi panjang: $luas <br>";
echo "Keliling persegi panjang: $keliling";
?>
